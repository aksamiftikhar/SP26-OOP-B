# JavaFX KeyEvent and MouseEvent Demo

This project is designed for a short JavaFX lecture on important events other than `ActionEvent`.

It demonstrates:

1. `KeyEvent`
   - `onKeyPressed`
   - `onKeyTyped`
   - `onKeyReleased`

2. `MouseEvent`
   - `onMouseEntered`
   - `onMouseExited`
   - `onMouseMoved`
   - `onMousePressed`
   - `onMouseDragged`
   - `onMouseReleased`
   - `onMouseClicked`

## Event handling style

No manual event registration is used.

There is no code like:

```java
node.setOnMouseClicked(...);
node.setOnKeyPressed(...);
```

Instead, handlers are connected through FXML/SceneBuilder:

```xml
<TextField onKeyPressed="#handleKeyPressed"/>
<StackPane onMouseClicked="#handleMouseClicked"/>
```

The corresponding controller methods are annotated with `@FXML`.

## Run using Maven

From the project folder:

```bash
mvn javafx:run
```

## Run from IntelliJ

Run:

```java
com.oop.gui.Launcher
```

or use:

```text
Maven -> Plugins -> javafx -> javafx:run
```

## Main teaching points

### KeyEvent

Use `KEY_PRESSED` for physical/special keys:

```java
event.getCode();      // ENTER, ESCAPE, A, UP, DOWN
event.isControlDown();
event.isShiftDown();
```

Use `KEY_TYPED` for actual typed characters:

```java
event.getCharacter();
```

Use `KEY_RELEASED` when you need to know when the key is released.

### MouseEvent

Common methods:

```java
event.getX();          // x-position inside the node
event.getY();          // y-position inside the node
event.getButton();     // PRIMARY, SECONDARY, MIDDLE
event.getClickCount(); // single click, double click
event.isPrimaryButtonDown();
```

## Suggested 30-minute lecture flow

1. 5 minutes: Event object idea
   - Event handler receives an event object.
   - The event object contains details about what happened.

2. 10 minutes: KeyEvent
   - `getCode()`
   - `getCharacter()`
   - modifier keys: Ctrl, Shift
   - Enter/Escape example

3. 10 minutes: MouseEvent
   - x/y coordinates
   - clicked vs pressed vs released
   - double-click
   - dragging

4. 5 minutes: Summary
   - `ActionEvent`: general control action
   - `KeyEvent`: keyboard details
   - `MouseEvent`: mouse details
