module com.example.demo_javafx_event_sp26 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;


    opens com.example.demo_javafx_event_sp26 to javafx.fxml;
    exports com.example.demo_javafx_event_sp26;
}