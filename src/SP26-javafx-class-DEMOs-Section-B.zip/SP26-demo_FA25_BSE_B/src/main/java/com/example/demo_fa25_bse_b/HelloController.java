package com.example.demo_fa25_bse_b;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.DragEvent;

public class HelloController {


    @FXML
    private Label welcomeText;
    @FXML
    private Button btnHello;
    @FXML
    private Button btn1;

    @FXML
    public void onHelloButtonClick(ActionEvent actionEvent) {
        welcomeText.setText("Hello " + welcomeText.getText() + "!");
    }

    @FXML
    public void onBtn1Click(Event event) {
        welcomeText.setText("dragging btn1!");

    }
}
