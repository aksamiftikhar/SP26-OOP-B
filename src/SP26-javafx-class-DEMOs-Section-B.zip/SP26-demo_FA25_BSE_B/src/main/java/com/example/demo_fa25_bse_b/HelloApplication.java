package com.example.demo_fa25_bse_b;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Temp123.fxml"));

//        Button btn = new Button("Hello World how are you?");
//        Button btn2 = new Button("Bye");
////        btn.setMaxWidth(300);
//        StackPane sp = new StackPane();
//
//        sp.getChildren().add(btn);
//        sp.getChildren().add(btn2);
//
//        Scene scene = new Scene(sp);
//
//
//        stage.setTitle("Hello!");
//        stage.setWidth(600);
//        stage.setHeight(400);

        Scene scene2 = new Scene(fxmlLoader.load());
        stage.setScene(scene2);
        stage.show();

    }
}
