module com.example.demo_fa25_bse_b {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.demo_fa25_bse_b to javafx.fxml;
    exports com.example.demo_fa25_bse_b;
}