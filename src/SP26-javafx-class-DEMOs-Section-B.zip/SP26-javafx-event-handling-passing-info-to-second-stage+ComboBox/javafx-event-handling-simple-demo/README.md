# JavaFX Event Handling Simple Demo

This is a deliberately small JavaFX + FXML + SceneBuilder demo for students who have already learned:

- Basic JavaFX screen loading
- `Application`, `Stage`, `Scene`
- Basic layout creation in SceneBuilder
- Basic properties of controls/panes in SceneBuilder

The demo now focuses only on:

- `fx:controller`
- `fx:id`
- `@FXML` fields
- `onAction`
- Controller methods
- Reading input from controls
- Updating labels/text areas
- Showing a simple `Alert`

No CSS, no Maven, no multiple screens, no TableView, no model/repository classes.

## Folder Structure

```text
javafx-event-handling-simple-demo/
└── src/com/oop/gui/
    ├── MainApp.java
    ├── EventDemoController.java
    └── event-demo.fxml
```

## How to Run in IntelliJ IDEA

1. Open the folder `javafx-event-handling-simple-demo` in IntelliJ IDEA.
2. Mark `src` as Sources Root:
   - Right-click `src`
   - Choose `Mark Directory as > Sources Root`
3. Make sure your JavaFX SDK is added:
   - `File > Project Structure > Libraries > + > Java`
   - Select your JavaFX SDK `lib` folder, e.g. `C:\javafx-sdk-24\lib`
4. Open `src/com/oop/gui/MainApp.java`.
5. Run the `main()` method.

If IntelliJ shows a JavaFX runtime error, add this to VM options:

```text
--module-path "C:\javafx-sdk-24\lib" --add-modules javafx.controls,javafx.fxml
```

Change the path according to your JavaFX SDK location.

## Demo Controls

- Name TextField: pressing Enter runs an event handler.
- Department ComboBox: changing the department runs an event handler.
- Library/Sports CheckBoxes: selecting/unselecting runs an event handler.
- Submit Button: validates and displays submitted information.
- Clear Button: clears the form.
