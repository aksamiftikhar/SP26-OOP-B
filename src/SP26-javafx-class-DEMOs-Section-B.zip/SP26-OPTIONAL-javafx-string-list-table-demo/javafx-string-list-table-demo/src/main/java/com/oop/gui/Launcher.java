package com.oop.gui;

/*
 * Run this class from the IDE if directly running MainApp gives:
 * "JavaFX runtime components are missing".
 *
 * You can also run the project from terminal:
 * mvn javafx:run
 */
public class Launcher {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
