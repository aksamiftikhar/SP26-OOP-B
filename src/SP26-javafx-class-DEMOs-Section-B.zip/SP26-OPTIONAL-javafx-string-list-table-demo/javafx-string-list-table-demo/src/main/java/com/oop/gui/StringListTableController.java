package com.oop.gui;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class StringListTableController {

    @FXML
    private TextField itemTextField;

    @FXML
    private ListView<String> itemListView;

    @FXML
    private TableView<String> itemTableView;

    @FXML
    private TableColumn<String, String> itemColumn;

    @FXML
    private Label statusLabel;

    private final ObservableList<String> items =
            FXCollections.observableArrayList(
                    "Computer Science",
                    "Software Engineering",
                    "Artificial Intelligence"
            );

    @FXML
    public void initialize() {

        // Both controls use the same data list.
        // So if an item is added/removed, both ListView and TableView update.
        itemListView.setItems(items);


        itemTableView.setItems(items);

        // A TableView needs columns.
        // Here each row is a String, so the column displays the String itself.
        itemColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue())
        );
    }

    @FXML
    private void handleAddItem() {
        String text = itemTextField.getText();

        if (text == null || text.trim().isEmpty()) {
            statusLabel.setText("Status: Please enter a value.");
            return;
        }

        items.add(text.trim());
        itemTextField.clear();

        statusLabel.setText("Status: Item added.");
    }

    @FXML
    private void handleShowSelected() {
        String selectedFromList =
                itemListView.getSelectionModel().getSelectedItem();

        String selectedFromTable =
                itemTableView.getSelectionModel().getSelectedItem();

        statusLabel.setText(
                "ListView selected: " + selectedFromList
                        + " | TableView selected: " + selectedFromTable
        );
    }

    @FXML
    private void handleRemoveSelected() {
        String selected =
                itemListView.getSelectionModel().getSelectedItem();

        if (selected == null) {
            selected = itemTableView.getSelectionModel().getSelectedItem();
        }

        if (selected == null) {
            statusLabel.setText("Status: No item selected.");
            return;
        }

        items.remove(selected);
        statusLabel.setText("Status: Removed " + selected);
    }

    @FXML
    private void handleClearAll() {
        items.clear();
        statusLabel.setText("Status: All items cleared.");
    }
}
