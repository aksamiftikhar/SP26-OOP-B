# JavaFX String ListView and TableView Demo

This is a simple JavaFX project for teaching:

1. `ListView<String>`
2. `TableView<String>`

No custom classes are used. The project intentionally keeps the example minimal.

## Main teaching idea

Both controls use the same data list:

```java
ObservableList<String> items
```

The `ListView<String>` displays the strings directly.

The `TableView<String>` also stores strings, but because a table needs columns, the column is connected using:

```java
itemColumn.setCellValueFactory(cellData ->
        new SimpleStringProperty(cellData.getValue())
);
```

Here:

```java
cellData.getValue()
```

is the current row value, which is a `String`.

## Event handling style

Events are connected in FXML/SceneBuilder using `onAction`.

Example:

```xml
<Button text="Add" onAction="#handleAddItem"/>
```

The controller has:

```java
@FXML
private void handleAddItem() {
    ...
}
```

No manual event registration such as `button.setOnAction(...)` is used.

## Run using Maven

From the project folder:

```bash
mvn javafx:run
```

## Run from IntelliJ

Run:

```java
com.oop.gui.Launcher
```

or use:

```text
Maven -> Plugins -> javafx -> javafx:run
```

## Files

```text
src/main/java/com/oop/gui/MainApp.java
src/main/java/com/oop/gui/Launcher.java
src/main/java/com/oop/gui/StringListTableController.java
src/main/resources/com/oop/gui/string-list-table-demo.fxml
pom.xml
```
